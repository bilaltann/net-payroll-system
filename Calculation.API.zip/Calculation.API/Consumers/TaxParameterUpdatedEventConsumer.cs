﻿using Calculation.API.Services;
using Calculation.API.Services.Interfaces;
using MassTransit;
using Shared.Events;

namespace Calculation.API.Consumers
{
    public class TaxParameterUpdatedEventConsumer(IParameterCacheService _cacheService) : IConsumer<TaxParameterUpdatedEvent>
    {
        public Task Consume(ConsumeContext<TaxParameterUpdatedEvent> context)
        {
            var message  = context.Message;
            _cacheService.Set(message.Key, message.Year, message.Value);

            Console.WriteLine($"[Event Received] {message.Key} - {message.Year} => {message.Value}");
            return Task.CompletedTask;

        }
    }
}
