using MassTransit;
using Shared.Contracts;
using Shared.Events;
using Calculation.API.Services;
using Calculation.API.Consumers;
using Calculation.API.Services.Clients;
using Calculation.API.DTOs;
using Calculation.API.Services.Calculators;
using Calculation.API.Services.Interfaces;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ? MassTransit setup (hem request-client hem consumer)
builder.Services.AddMassTransit(x =>
{
    x.AddConsumer<TaxParameterUpdatedEventConsumer>();

    x.UsingRabbitMq((context, cfg) =>
    {
        cfg.Host(builder.Configuration["RabbitMQ"]);

        cfg.ReceiveEndpoint("tax-parameter-updated-event", e =>
        {
            e.ConfigureConsumer<TaxParameterUpdatedEventConsumer>(context);
        });
    });
});

// Cache servisini tan�t
builder.Services.AddSingleton<IParameterCacheService, ParameterCacheService>();
builder.Services.AddScoped<ICalculator<NetPayInputDto, BrutGelirResultDto>, BrutGelirCalculator>();


builder.Services.AddHttpClient<TaxParameterClient>(client =>
{
    client.BaseAddress = new Uri("http://localhost:5259"); // Docker'da service ad� olacak
});



var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.UseRouting();
app.MapControllers();
app.Run();
