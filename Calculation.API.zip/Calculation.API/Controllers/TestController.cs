﻿using Calculation.API.DTOs;
using Calculation.API.Services;
using Calculation.API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Calculation.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TestController : ControllerBase
    {
        private readonly ICalculator<NetPayInputDto, BrutGelirResultDto> _brutCalculator;

        public TestController(ICalculator<NetPayInputDto, BrutGelirResultDto> brutCalculator)
        {
            _brutCalculator = brutCalculator;
        }

        [HttpPost("brut-gelir")]
        public async Task<IActionResult> Hesapla([FromBody]NetPayInputDto input)
        {
            var sonuc = await _brutCalculator.HesaplaAsync(input);
            return Ok(sonuc);
        }

    }
}
