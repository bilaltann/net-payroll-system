﻿using Calculation.API.DTOs;
using Calculation.API.Services.Interfaces;

namespace Calculation.API.Services.Calculators
{
    public class BrutGelirCalculator : ICalculator<NetPayInputDto, BrutGelirResultDto>
    {
        public Task<BrutGelirResultDto> HesaplaAsync(NetPayInputDto input)
        {
            var yemekYardimi = input.CalismaGunu * input.GunlukYemekUcreti;
            var fazlaMesai = input.FazlaMesaiSaati * input.SaatlikMesaiUcreti;

            var toplamBrut = input.AylikMaas + yemekYardimi + fazlaMesai;

            var result = new BrutGelirResultDto
            {
                ToplamBrutGelir = toplamBrut
            };

            return Task.FromResult(result);

        }
    }
}
