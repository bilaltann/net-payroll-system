﻿using Calculation.API.Services.Interfaces;
using System.Collections.Concurrent;

namespace Calculation.API.Services
{
    public class ParameterCacheService : IParameterCacheService
    {
        // Key: damga_vergisi-2025
        private readonly ConcurrentDictionary<string, decimal> _cache = new();

        public void Set(string key, int year, decimal value)
        {
            _cache[$"{key}-{year}"] = value;
        }

        public decimal? Get(string key, int year)
        {
            return _cache.TryGetValue($"{key}-{year}", out var value) ? value : null;
        }
    }
}
