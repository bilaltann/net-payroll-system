﻿using Shared.Enums;

namespace Calculation.API.Services.Clients
{
    public class TaxParameterClient(HttpClient _httpClient)
    {

        public async Task<decimal?> GetTaxParameterValueAsync(TaxParameterName name)
        {
            var response = await _httpClient.GetAsync($"/api/taxparameters/by-name/{name}");

            if (!response.IsSuccessStatusCode)
                return null;

            var content = await response.Content.ReadAsStringAsync();
            return decimal.TryParse(content, out var taxValue) ? taxValue : null;
        }
    }
}
