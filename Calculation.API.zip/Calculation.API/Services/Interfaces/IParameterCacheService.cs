﻿namespace Calculation.API.Services.Interfaces
{
        public interface IParameterCacheService
        {
            void Set(string key, int year, decimal value);
            decimal? Get(string key, int year);
        }
    
}
