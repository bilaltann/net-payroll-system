﻿namespace Calculation.API.DTOs
{
    public class NetPayInputDto
    {
        public decimal AylikMaas { get; set; }
        public int CalismaGunu { get; set; }
        public decimal GunlukYemekUcreti { get; set; } // Günlük yemek yardım tutarı
        public int FazlaMesaiSaati { get; set; }
        public decimal SaatlikMesaiUcreti { get; set; }
    }
}
