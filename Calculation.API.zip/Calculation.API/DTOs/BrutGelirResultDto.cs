﻿namespace Calculation.API.DTOs
{
    public class BrutGelirResultDto
    {
        public decimal ToplamBrutGelir { get; set; }

    }
}
